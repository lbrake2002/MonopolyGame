package cosa.models;

public class Utility extends Property
{
    public static final int[] MULTIPLIERS = {4, 10};
}
