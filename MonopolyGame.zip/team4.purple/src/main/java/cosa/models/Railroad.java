package cosa.models;

public class Railroad extends Property
{
    public static final int[] PRICES = {25, 50, 100, 200};

}
