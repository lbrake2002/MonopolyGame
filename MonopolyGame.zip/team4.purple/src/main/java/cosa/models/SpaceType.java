package cosa.models;

/**
 * This class holds enumerations for the different types of GameSpaces in the Monopoly game
 */

public enum SpaceType
{
    PROPERTY;
}
