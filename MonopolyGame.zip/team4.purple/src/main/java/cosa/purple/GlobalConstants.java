package cosa.purple;

public class GlobalConstants {
    public static final String CONNECTION_STRING ="jdbc:sqlite:users.db";
}
