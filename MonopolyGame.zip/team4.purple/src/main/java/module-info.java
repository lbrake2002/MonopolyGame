open module cosa.purple{
    requires javafx.graphics;
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires ormlite.jdbc;
    requires jakarta.validation;
    requires org.controlsfx.controls;
}