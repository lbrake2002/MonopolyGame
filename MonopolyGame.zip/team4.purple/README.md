# CST Team Name
## First Year Student Project
## Project/Product Name
### Clients:
### Supervisor:

### Team Members:
1. Team Member1
2. Team Member2
3. Team Member3
4. Team Member4
5. Team Member5
6. Team Member6
7. Team Member7
8. Team Member8

### Frameworks/ Technologies Used:
1. Java 17
2. and list the rest